package com.restapipostgresql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapipostgresqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapipostgresqlApplication.class, args);
	}

}
